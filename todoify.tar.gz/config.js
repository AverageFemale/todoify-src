module.exports = {
  'mongourl': process.env['mongourl'],
  'embedColor': "#303236",
  'links': {
    'invite': 'https://discord.com/api/oauth2/authorize?client_id=905523747887415327&permissions=8&redirect_uri=https%3A%2F%2Fdiscord.com%2Finvite%2FA2zAjH2A97&response_type=code&scope=bot%20applications.commands%20guilds.join',
    'ss': 'https://discord.com/invite/A2zAjH2A97',
    'topgg': 'https://top.gg/bot/905523747887415327'
  },
  
  'emojis': {
    'done': '<:done:900815633141362718>',
    'notDone': '<:notDone:900815633934061599>',
    'inProgress': '<:inProgress:905861977216253972>',
    'topgg': '<:topgg:907687468218867713>',
    'server': '<:server:907687005595504710>',
    'todoify': '<:todoify:907686798128463908>',
    'ping': '<:ping:908414255303389236>',
    'uptime': '<:uptime:908414252950360125>',
    'djs': '<:djs:908414256582627379>',
    'node': '<:node:908414258105155644>',
    'user': '<:user:908414259267006474>',
    'channel': '<:channel:908414260265222144>',
    'dot': '<:whiteDot:908415353103712256>'
  }
}